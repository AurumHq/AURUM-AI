# AURUM AI — Founder Edition

Owner: Kehinda Mitchell  
Product: AI Gold Trading Copilot

## Upload these four files to the root of the GitHub repository

- `index.html`
- `manifest.json`
- `sw.js`
- `README.md`

## Publish with GitHub Pages

Open repository **Settings** → **Pages** → Source: **Deploy from a branch** → Branch: **main** → Folder: **/(root)** → **Save**.

This version is a private paper-trading alpha. It does not place live broker orders.
